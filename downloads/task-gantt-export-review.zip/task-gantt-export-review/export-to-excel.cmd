@echo off
setlocal
cd /d "%~dp0"
if exist "C:\Distr_Local\node-v22.23.4-win-x64\node.exe" set "PATH=C:\Distr_Local\node-v22.23.4-win-x64;%PATH%"
where node.exe >nul 2>nul
if errorlevel 1 goto no_node
node export-review.cjs --open
if errorlevel 1 goto failed
echo.
echo Open tasks-review.xlsx in the export folder.
echo Your working database was not changed.
pause
exit /b 0
:no_node
echo Node.js was not found. Use the same Node.js as your working app.
pause
exit /b 1
:failed
echo Export stopped. Keep this window open and copy the error above.
pause
exit /b 1
