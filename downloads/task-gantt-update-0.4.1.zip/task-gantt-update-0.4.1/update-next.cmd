@echo off
setlocal
cd /d "%~dp0"
if exist "C:\Distr_Local\node-v22.23.4-win-x64\node.exe" set "PATH=C:\Distr_Local\node-v22.23.4-win-x64;%PATH%"
node scripts\update-next.cjs %*
if errorlevel 1 goto failed
echo Update finished. Run start-next.cmd in task-gantt-app-next.
pause
exit /b 0
:failed
echo Update stopped. Keep this window open and copy the error above.
pause
exit /b 1
